Please refer to: 

https://docs.microsoft.com/en-us/visualstudio/debugger/debug-interface-access/Dia2Dump-sample
